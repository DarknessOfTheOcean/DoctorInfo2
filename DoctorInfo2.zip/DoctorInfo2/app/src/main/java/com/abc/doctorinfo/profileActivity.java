package com.abc.doctorinfo;


import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

public class profileActivity extends AppCompatActivity implements BottomNavigationView.OnNavigationItemSelectedListener {
private Button signBtn;
private  FirebaseUser firebaseUser;
String TAG="something";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        signBtn=(Button)findViewById(R.id.signOutBtn);

        firebaseUser=FirebaseAuth.getInstance().getCurrentUser();
        BottomNavigationView bottomNavigationView=(BottomNavigationView)findViewById(R.id.bottomNavigation);
        loadFragment(new doctorsFragment());
        bottomNavigationView.setOnNavigationItemSelectedListener(this);

        signBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseAuth.getInstance().signOut();

                startActivity(new Intent(getApplicationContext(),signInActivity.class));
                Log.d(TAG, "onClick: successfully signed out"+firebaseUser);
                finish();
            }
        });
    }

    private boolean loadFragment(Fragment fragment)
    {
        if(fragment!=null)
        {
            getSupportFragmentManager().beginTransaction().replace(R.id.fragmentHolderId,fragment).commit();
            return true;
        }
        return false;
    }


    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {

        Fragment fragment=null;
        switch(item.getItemId())
        {
            case R.id.person_id:
                fragment=new profileFragment();
                break;
            case R.id.doctor_id:
                fragment=new doctorsFragment();
                break;

        }
        return loadFragment(fragment);
    }
}
